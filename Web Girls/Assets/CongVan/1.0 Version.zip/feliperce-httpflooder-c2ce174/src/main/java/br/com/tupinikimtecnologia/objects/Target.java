package br.com.tupinikimtecnologia.objects;

/**
 * Created by felipe on 05/04/16.
 */
public class Target {

    protected int id;
    protected String url;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}

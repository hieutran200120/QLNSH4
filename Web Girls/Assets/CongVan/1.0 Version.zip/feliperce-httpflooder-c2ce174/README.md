# HttpFlooder
A simple Java POST and GET flooder.

<b><h3>Features:</b></h3>
- Send massive POST and GET requests
- Delay control
- Store data on SQLite Database
- Random data
- Random user agent
